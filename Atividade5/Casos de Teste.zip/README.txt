Arquivo zip gerado em: 18/10/2021 14:00:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade avaliativa 05 - Métodos de ordenação: Shell e Quick